package symbol_table;

import lexical_analyzer.*;

public class TokenWordTypeArray extends TokenWordType
{
	public TokenWordTypeArray (int size_in, TokenWordType type_in)
	{
		super("[]", Tag.INDEX, size_in*type_in.width);
		size = size_in;
		type = type_in;
	}

	public String toString()
	{
		return "[" + size + "] " + type.toString();
	}

	public TokenWordType type;
	public int size = 1;
}