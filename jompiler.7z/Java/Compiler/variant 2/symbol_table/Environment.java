package symbol_table;

import java.util.*;

import lexical_analyzer.*;
import syntax_tree.*;

// represents chain of symbol tables in the current program execution moment
public class Environment
{
	public Environment (Environment previous_in)
	{
		table = new Hashtable();
		previous = previous_in;		
	}

	public void put (Token token, NodeExpressionId id)
	{
		table.put(token, id);
	}

	public NodeExpressionId get (Token token)
	{
		for (Environment env = this; env != null; env = env.previous)
		{
			NodeExpression found = env.table.get(token);
			if (found != null)
				return found;
		}
		
		return null;
	}
	// PUBLIC BLOCK END

	protected Environment previous;
	// PROTECTED BLOCK END

	private Hashtable table;
	// PRIVATE BLOCK END
}