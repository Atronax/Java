package symbol_table;

import lexical_analyzer.*;

public class TokenWordType extends TokenWord
{
	public TokenWordType (String lexeme_in, int tag_in, int width_in)
	{
		super (lexeme_in, tag_in);
		width = width_in;
	}

	public static boolean numeric (TokenWordType type)
	{
		if (type == Type.Char || type == Type.Int || type == Type.Float)
			return true;
		else
			return false;
	}

	public static TokenWordType max (TokenWordType type1, TokenWordType type2)
	{
		if (!numeric(type1) || !numeric(type2))
			return null;
		else if (type1 == TokenWordType.Float || type2 == TokenWordType.Float)
			return TokenWordType.Float;
		else if (type1 == TokenWordType.Int || type2 == TokenWordType.Int)
			return TokenWordType.Int;
		else
			return TokenWordType.Char;
	}

	public int width = 0; // used for memory allocation
	public static final TokenWordType Int = new TokenWordType ("int", Tag.BASIC, 4); // reserved basic types
	public static final TokenWordType Float = new TokenWordType ("float", Tag.BASIC, 8);
	public static final TokenWordType Char = new TokenWordType ("char", Tag.BASIC, 1);
	public static final TokenWordType Bool = new TokenWordType ("bool", Tag.BASIC, 1);
}