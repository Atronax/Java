package syntax_tree;

import lexical_analyzer.*;

public class Node
{		
	public int newlabel()
	{
		return ++labels;
	}

	public void emitlabel(int i)
	{
		System.out.print("L" + i + ":");
	}

	public void emit(String s)
	{
		System.out.println("\t" + s);
	}
	// PUBLIC BLOCK END
		
	private Node()
	{
		line = Lexer.line;
	}

	private void error (String error_string)
	{
		throw new Error ("near line " + line + " : " + error_string);
	}
	
	private int line = 0;
	private static int labels = 0; // for three-address code printing
	// PRIVATE BLOCK END
}