package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionLogical extends NodeExpression
{
	public NodeExpressionLogical (Token token_in, NodeExpression expression1_in, NodeExpression expression2_in)
	{
		super (token_in, null);
		expression1 = expression1_in;
		expression2 = expression2_in;
		type = check (expression1.type, expression2.type);
		if (type == null)
			error ("type error");
	}

	public TokenWordType check (TokenWordType type1, TokenWordType type2)
	{
		if (type1 == TokenWordType.Bool && type2 == TokenWordType.Bool)
			return TokenWordType.Bool;
		else
			return null;
	}

	// code with gotos may be also used to return boolean value
	public NodeExpression generate()
	{
		int false_path = newlabel();		
		int true_path = newlabel();		
		
		NodeExpressionTemporary t = new NodeExpressionTemporary (type);
		this.jumping(0, false_path);

		emit(t.toString() + " = true"); // <<< true path : step 1
		emit("goto L" + true_path); // <<< true path : step 2
		emitlabel(false_path); // <<< false path : step 1 : new label "false_path"
		emit(t.toString() + " = false"); <<< false path : step 2
		emitlabel(true_path); // <<< true path : step 3 : new label "true_path"

		return t;
	}

	public String toString()
	{
		return expression1.toString() + " " + operator.toString() + " " + expression2.toString();
	}

	public NodeExpression expression1;
	public NodeExpression expression2;
}