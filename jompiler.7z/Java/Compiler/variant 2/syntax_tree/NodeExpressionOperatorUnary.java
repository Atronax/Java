package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionOperatorUnary extends NodeExpressionOperator
{
	public NodeExpressionOperatorUnary (Token token_in, NodeExpression expression_in)
	{
		super (token_in, null);
		expression = expression_in;

		type = TokenWordType.max(TokenWordType.Int, expression.type);
		if (type == null)
			error ("type error");
	}

	public NodeExpression generate()
	{
		return new NodeExpressionOperatorUnary (operator, expression.reduce());
	}

	public String toString()
	{
		return operator.toString() + " " expression.toString();
	}
	
	public NodeExpression expression;
}