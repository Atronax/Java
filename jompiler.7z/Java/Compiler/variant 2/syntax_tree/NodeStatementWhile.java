package syntax_tree;

import symbol_table.*;

public class NodeStatementWhile extends NodeStatement
{
	public NodeStatementWhile()
	{
		expression = null;
		statement = null;
	}

	public void init (NodeExpression expression_in, NodeStatement statement_in)
	{
		expression = expression_in;
		statement = statement_in;
		if (expression.type != TokenWordType.Bool)
			expression.error ("boolean required in while");
	}

	public void generate (int start, int end)
	{
		this.end = end; // save label for break

		expression.jumping(0, end);
		int label = newlabel(); // label for statement
		emitlabel(label);
		statement.generate(label, start);
		emit("goto L" + start);
	}

	private NodeExpression expression;
	private NodeStatement statement;
}