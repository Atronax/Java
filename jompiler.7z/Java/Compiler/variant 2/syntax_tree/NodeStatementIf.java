package syntax_tree;

import symbol_table.*;

public class NodeStatementIf extends NodeStatement
{
	public NodeStatementIf (NodeExpression expression_in, NodeStatement statement_in)
	{
		expression = expression_in;
		statement = statement_in;
		if (expression.type != TokenWordType.Bool)
			expression.error ("boolean required in if");
	}
	
	public void generate (int start, int end)
	{
		int label = newlabel(); // label for statement
		expression.jumping(0, end); // pass to statement if true, go to end if false
		emitlabel(label);
		statement.generate(label, end);
	}
	
	private NodeExpression expression;
	private NodeStatement statement;
}