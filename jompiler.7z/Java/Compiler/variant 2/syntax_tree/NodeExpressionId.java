package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionId extends NodeExpression
{
	public NodeExpressionId (TokenWord id, TokenWordType id_type, int offset_in)
	{
		super (id, id_type);
		offset = offset_in;
	}

	public int offset; // relative address	
}