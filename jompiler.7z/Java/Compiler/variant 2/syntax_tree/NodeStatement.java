package syntax_tree;

public class Statement extends Node
{
	public Statement()	{}

	// start - start of the statement's code
	// end - first command after current statement's code
	public void generate (int start_in, int end_in) { }
	
	public static Statement Null = new Statement();
	public static Statement Enclosing = Statement.Null;

	private int end;
}