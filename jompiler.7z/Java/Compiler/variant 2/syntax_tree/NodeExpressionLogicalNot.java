package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionLogicalNot extends NodeExpressionLogical
{
	public NodeExpressionLogicalNot (Token token_in, NodeExpression expression_in)
	{
		super (token_in, expression_in, expression_in);
	}

	public void jumping (int true_path, int false_path)
	{
		expression2.jumping(false_path, true_path);
	}

	public String toString()
	{
		return operator.toString() + " " + expression2.toString();
	}
}