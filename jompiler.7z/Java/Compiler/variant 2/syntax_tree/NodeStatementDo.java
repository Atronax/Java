package syntax_tree;

import symbol_table.*;

public class NodeStatementDo extends NodeStatement
{
	public NodeStatementDo()
	{
		expression = null;
		statement = null;
	}

	public void init (NodeExpression expression_in, NodeStatement statement_in)
	{
		expression = expression_in;
		statement = statement_in;
		if (expression.type != TokenWordType.Bool)
			expression.error("boolean required in do");
	}

	public void generate (int start, int end)
	{
		this.end = end;
		
		int label = newlabel(); // label for statement
		statement.generate(end, label);
		emitlabel(label);
		expression.jumping(start,0);
	}

	private NodeExpression expression;
	private NodeStatement statement;

}