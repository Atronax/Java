package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionOperatorAccess extends NodeExpressionOperator
{
	public NodeExpressionOperatorAccess (NodeExpressionId array_in, NodeExpression index_in, TokenWordType type_in)
	{
		super (new TokenWord("[]", Tag.INDEX), type_in); // type_in - elements type after array aligning
		array = array_in;
		index = index_in;
	}

	public NodeExpression generate()
	{
		return new NodeExpressionOperatorAccess (array, index.reduce(), type);
	}

	public void jumping (int true_path, int false_path)
	{
		emit_jumps (reduce().toString(), true_path, false_path);
	}

	public String toString()	
	{
		return array.toString() + " [ " + index.toString() + " ] ";
	}

	public NodeExpressionId array;
	public NodeExpression index;
}