package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionOperatorArithmetic extends NodeExpressionOperator
{
	// our simple compiler just checks numeric types, but doesn't cast types if it can
	public NodeExpressionOperatorArithmetic (Token token_in, NodeExpression expression1_in, NodeExpression expression2_in)
	{
		super (token_in, null);
		expression1 = expression1_in;
		expression2 = expression2_in;
		type = TokenWordType.max (expression1.type, expression2.type);
		if (type == null)
			error ("type error");
	}

	public NodeExpression generate()
	{
		return new NodeExpressionOperatorArithmetic (operator, expression1.reduce(), expression2.reduce());
	}

	public String toString()
	{
		return expression1.toString() + " " + operator.toString() + " " + expression2.toString();
	}

	public NodeExpression expression1;
	public NodeExpression expression2;
}