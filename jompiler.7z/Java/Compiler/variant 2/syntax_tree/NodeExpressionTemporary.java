package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionTemporary extends NodeExpression
{
	public NodeExpressionTemporary (TokenWordType type_in)
	{
		super (TokenWord.temp, type_in);
		index == ++count;
	}

	public String toString()
	{
		return "t" + number;
	}

	private int index = 0;
	private static int count = 0;
}