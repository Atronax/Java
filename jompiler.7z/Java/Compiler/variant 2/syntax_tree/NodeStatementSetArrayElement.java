package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeStatementSetArrayElement extends NodeStatement
{
	public NodeStatementSetArrayElement (NodeExpressionOperatorAccess access, NodeExpression expression_in)
	{
		array = access.array;
		index = access.index;
		expression = expression_in;
		if (check(access.type, expression.type) == null)
			error("type error");
	}

	public TokenWordType check (TokenWordType type1, TokenWordType type2)
	{
		if (type1 instanceof TokenWordTypeArray || type2 instanceof TokenWordTypeArray)
			return null;
		else if (type1 == type2)
			return type2;
		else if (TokenWordType.numeric(type1) && TokenWordType.numeric(type2))
			return type2;
		else
			return null;
	}

	public void generate (int start, int end)
	{
		emit (array.toString() + " [ " + index.reduce().toString() + " ] " + " = " + expression.reduce().toString();
	}

	public NodeExpressionId array;
	public NodeExpression index;
	public NodeExpression expression;
}