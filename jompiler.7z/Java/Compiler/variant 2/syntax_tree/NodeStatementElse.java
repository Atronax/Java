package syntax_tree;

import symbol_table.*;

public class NodeStatementElse extends Statement
{
	public NodeStatementElse (NodeExpression expression_in, NodeStatement statement1_in, NodeStatement statement2_in)
	{
		expression = expression_in;
		statement1 = statement1_in;
		statement2 = statement2_in;
		if (expression.type != TokenWordType.Bool)
			expression.error("boolean required in if");
	}

	public void generate (int start, int end)
	{
		int label1 = newlabel(); // label for statement1
		int label2 = newlabel(); // label for statement2
		expression.jumping(0, label2); // true - to statement1, false - to statement2
		emitlabel(label1);
		statement1.generate(label1, end);
		emit("goto L" + end);
		emitlabel(label2);
		statement2.generate(label2, end);
	}

	private NodeExpression expression;
	private NodeStatement statement1;
	private NodeStatement statement2;
}