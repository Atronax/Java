package syntax_tree;

public class NodeStatementSequence extends NodeStatement
{
	public NodeStatementSequence (NodeStatement statement1_in, NodeStatement statement2_in)
	{
		statement1 = statement1_in;
		statement2 = statement2_in;
	}

	public void generate (int start, int end)
	{
		if (statement1 == NodeStatement.Null)
			statement2.generate(start,end);
		else if (statement2 == NodeStatement.Null)
			statement1.generate(start,end);
		else
		{
			int label = newlabel(); // label for statement2
			statement1.generate(start, label);
			emitlabel(label);
			statement2.generate(label, end);
		}
	}

	private NodeStatement statement1;
	private NodeStatement statement2;
}