package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpression extends Node
{
	public NodeExpression (Token operator_in, TokenWordType type_in)
	{
		operator = operator_in;
		type = type_in;
	}

	// return right member of 3-adress code 
	// (for E = E1 + E2 -> x1 + x2, where x1 and x2 - adresses of E1 and E2)
	// this is correct if object is adress
	public NodeExpression generate()
	{
		return this;
	}

	// calculated expression into single adress, returns constant, identifier or temporary name
	// (for E -> t, where t stores E value)
	public NodeExpression reduce()
	{
		return this;
	}

	// next two functions used to generate code of logic expressions (if-else blocks)
	public void jumping (int true_path, int false_path)
	{
		emit_jumps (toString(), true_path, false_path);
	}

	public void emit_jumps (String test, int true_path, int false_path)
	{
		if (true_path != 0 && false_path != 0)
		{
			emit ("if " + test + " goto L" + true_path);
			emit ("goto L" + false_path);
		}
		else if (true_path != 0)
			emit ("if " + test + " goto L" + true_path);
		else if (false_path != 0)
			emit ("iffalse " + test + " goto L" + false_path);
	}

	public String toString()
	{
		return operator.toString();
	}

	public Token operator;
	public TokenWordType type;
	// PUBLIC BLOCK END
}