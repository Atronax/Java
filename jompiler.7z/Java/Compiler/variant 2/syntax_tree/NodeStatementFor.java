package syntax_tree;

import symbol_table.*;

// FOR is a construction of type for (expr1; expr2; expr3) stmt;
// it is the same as expr1; while (expr2) {stmt; expr2;}
public class NodeStatementFor extends NodeStatement
{
	public NodeStatementFor()
	{
		expression1 = null;
		expression2 = null;
		expression3 = null;
		statement = null;
	}

	public init (NodeExpression expression1_in, NodeExpression expression2_in, NodeExpression expression3_in, NodeStatement statement_in)
	{
		expression1 = expression1_in;
		expression2 = expression2_in;
		expression3 = expression3_in;
		statement = statement_in;

		if (expression2.type != TokenWordType.Bool)
			expression2.error ("boolean required as expr2 in for");
	}

	public void generate (int start, int end)
	{
		this.end = end; // save label for break;

		// expr1
		expression1.reduce().generate();
		// label for inner while
		int label_while = newlabel();
		emitlabel (label_while);		
		// expr2
		expression2.jumping(0, end);		
		// label for stmt
		int label_stmt = newlabel();
		emitlabel (label_stmt);
		// stmt
		statement.generate(label_stmt, label_while);
		// expr3
		expression3.reduce().generate();
		// next while iteration
		emit("goto L" + label_while);
		
	}

	private NodeExpression expression1;
	private NodeExpression expression2;
	private NodeExpression expression3;
	private NodeStatement statement;	
}