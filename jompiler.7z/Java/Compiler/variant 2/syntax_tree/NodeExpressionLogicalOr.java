package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionLogicalOr extends NodeExpressionLogical
{
	public NodeExpressionLogicalOr (Token token_in, NodeExpression expression1_in, NodeExpression expression2_in)
	{
		super (token_in, expression1_in, expression2_in);
	}

	// generates goto code for boolean expression B = B1 || B2
	// since B is true if B1 is true, true path of B1 must be true_path, 
	// and false path corresponds to first command of B2
	// true path and false path for B2 is the same as for whole B
	public void jumping (int true_path, int false_path)
	{
		int label = (true_path != 0) ? true_path : newlabel();

		expression1.jumping(label, 0);
		expression2.jumping(true_path, false_path);

		if (true_path == 0)
			emitlabel(label);
	}
}