package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;
 
public class NodeExpressionLogicalAnd extends NodeExpressionLogical
{
	public NodeExpressionLogicalAnd (Token token_in, NodeExpression expression1_in, NodeExpression expression2_in)
	{
		super (token_in, expression1_in, expression2_in);
	}

	public void jumping (int true_path, int false_path)
	{
		int label = (false_path != 0) ? false_path : newlabel();
		
		expression1.jumping(0, label);
		expression2.jumping(true_path, false_path);

		if (false_path == 0)
			emitlabel (label);
	}	
}