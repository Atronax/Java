package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionLogicalRelational extends NodeExpressionLogical
{
	public NodeExpressionLogicalRelational (Token token_in, NodeExpression expression1_in, NodeExpression expression2_in)
	{
		super (token_in, expression1_in, expression2_in);
	}

	public TokenWordType check (TokenWordType type1, TokenWordType type2)
	{
		if (type1 instanceof TokenWordTypeArray || type2 instanceof TokenWordTypeArray)
			return null;
		else if (type1 == type2)
			return TokenWordType.Bool;
		else
			return null;
	}

	public void jumping (int true_path, int false_path)
	{
		NodeExpression expr1 = expression1.reduce();
		NodeExpression expr2 = expression2.reduce();
		String test = expr1.toString() + " " + operator.toString() + " " + expr2.toString();
		
		emit_jumps(test, true_path, false_path);
	}
}