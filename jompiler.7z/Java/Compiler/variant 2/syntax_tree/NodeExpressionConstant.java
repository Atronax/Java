package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionConstant extends NodeExpression
{
	public NodeExpressionConstant (Token token_in, TokenWordType type_in)
	{
		super (token_in, type_in);
	}

	public NodeExpressionConstant (int value)
	{
		super(new TokenInteger(value), TokenWordType.Int);
	}

	public void jumping (int true_path, int false_path)
	{
		if (this == True && true_path != 0)
			emit ("goto L" + true_path);
		else if (this == False && false_path != 0)
			emit ("goto L" + false_path);
	}

	public static final NodeExpressionConstant True = new NodeExpressionConstant (TokenWord.True, TokenWordType.Bool);
	public static final NodeExpressionConstant False = new NodeExpressionConstant (TokenWord.False, TokenWordType.Bool);
}