package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeExpressionOperator extends NodeExpression
{
	public NodeExpressionOperator (Token token_in, TokenWordType type_in)
	{
		super (token_in, type_in);
	}

	public NodeExpression reduce()
	{
		NodeExpression expression = generate();
		NodeExpressionTemporary t = new NodeExpressionTemporary(type);
		emit (t.toString() + " = " + expression.toString());
		return t;
	}	
}