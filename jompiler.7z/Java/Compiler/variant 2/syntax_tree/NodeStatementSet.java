package syntax_tree;

import lexical_analyzer.*;
import symbol_table.*;

public class NodeStatementSet extends NodeStatement
{
	public NodeStatementSet (NodeExpressionId id_in, NodeExpression expression_in)
	{
		id = id_in;
		expression = expression_in;
		if (check(id.type, expression.type) == null) // no type casting
			error ("type error");
	}

	public TokenWordType check (TokenWordType type1, TokenWordType type2)
	{
		if (TokenWordType.numeric(type1) && TokenWordType.numeric(type2))
			return type2;
		else if (type1 == TokenWordType.Bool && type2 == TokenWordType.Bool)
			return type2;
		else
			return null;
	}

	public void generate (int start, int end)
	{
		emit (id.toString() + " = " + expression.generate().toString()); // generates three-address code
	}	

	public NodeExpressionId id;
	public NodeExpression expression;
}