package syntax_tree;

public class NodeStatementBreak extends NodeStatement
{
	public NodeStatementBreak()
	{
		if (NodeStatement.Enclosing == null)
			error ("unenclosed break");
		
		statement = NodeStatement.Enclosing;
	}

	public void generate (int start, int end)
	{
		emit ("goto L" + statement.end);
	}

	private NodeStatement statement;
}