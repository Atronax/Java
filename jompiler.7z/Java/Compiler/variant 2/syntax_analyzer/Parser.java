package syntax_analyzer;

import java.io.*;

import lexical_analyzer.*;
import symbol_table.*;
import syntax_tree.*;

public class Parser
{
	public Parser (Lexer lexer_in) throws IOException
	{
		lexer = lexer_in;
		step();
	}	

	// program := block
	public void program() throws IOException
	{
		NodeStatement statement = block();

		int start = statement.newlabel();
		int end = statement.newlabel();

		statement.emitlabel(start);
		statement.generate(start, end);
		statement.emitlabel(end);
	}
	// PUBLIC BLOCK END

	// in this case, use of symbol table is explicit
	// environment_top variable stores top symbol table, environment_saved variable is a connection with previous symbol table
	// alternatively, you can add push and pop methods into Environment class, and have a static variable Environment.top
	// block := {declarations statements}
	private NodeStatement block() throws IOException
	{
		match_tag('{'};
		Environment environment_saved = environment_top;
		environment_top = new Environment(environment_top);
			declarations();
			NodeStatement statement = statements();		
		match_tag('}');
		environment_top = environment_saved;
		
		return statement;
	}

	// declarations give us tokens for ids in symbol table
	// also routes to commands that reserve memory for identifiers at runtime
	// declaration := type ID;
	private void declarations() throws IOException
	{
		while (token_foreseen.tag == Tag.BASIC)
		{					
			Token token = token_foreseen;
			TokenWordType type = type();			

			match_tag(Tag.ID);
			match_tag(';');
			
			environment_top.put (token, new NodeExpressionId((TokenWord)token, type, memory_used));
			memory_used += type.width;
		}
	}

	private TokenWordType type() throws IOException
	{
		TokenWordType type = (TokenWordType) token_foreseen; 
		match_tag(Tag.BASIC); // must be BASIC
		if (token_foreseen.tag != '[')
			return type;
		else
			return dimensional (type);
	}

	private TokenWordType dimensional (TokenWordType type) throws IOException
	{
		match_tag('[');
		Token token = token_foreseen;
		match_tag(Tag.INTEGER);
		match_tag(']');

		if (token_foreseen.tag == '[')
			type = dimentional (type);

		return new TokenWordTypeArray (((TokenInteger)token).value, type);
	}

	// statements := statement statements | null_statement
	private NodeStatement statements() throws IOException
	{
		if (token_foreseen.tag == '}')
			return NodeStatement.Null;
		else
			return new NodeStatementSequence (statement(), statements());
	}

	private NodeStatement statement() throws IOException
	{
		NodeExpression expression;
		NodeExpression expression2; // for
		NodeExpression expression3; // for

		NodeStatement statement;
		NodeStatement statement1;
		NodeStatement statement2;
		NodeStatement statement_enclosing; // for breaks

		switch (token_foreseen.tag)
		{
			// ; is an empty statement, so we return null statement
			case ';':
				step();
				return NodeStatement.Null;

			// no support for else if (new tag, new nodestatement subclass, some additions here)
			case Tag.IF:
				match_tag(Tag.IF);
				match_tag('(');
				expression = boolean_or();
				match_tag(')');
				statement1 = statement();
				if (token_foreseen.tag != Tag.ELSE)
					return new NodeStatementIf (expression, statement1);
				match_tag(Tag.ELSE);
				statement2 = statement();
					return new NodeStatementIf (expression, statement1, statement2);

			case Tag.WHILE:
				NodeStatementWhile whilenode = new NodeStatementWhile();
				statement_enclosing = NodeStatement.Enclosing;
				NodeStatement.Enclosing = whilenode;

					match_tag(Tag.WHILE);
					match_tag('(');
					expression = boolean_or();
					match_tag(')');
					statement1 = statement();
					whilenode.init(expression, statement1);

				NodeStatement.Enclosing = statement_enclosing;
				return whilenode;

			case Tag.DO:
				NodeStatementDo donode = new NodeStatementDo();
				statement_enclosing = NodeStatement.Enclosing;
				NodeStatement.Enclosing = donode;

					match_tag(Tag.DO);
					statement1 = statement();
					match_tag(Tag.WHILE);
					match_tag('(');
					expression = boolean_or();
					match_tag(')');
					match_tag(';');
					donode.init(expression, statement1);
				
				NodeStatement.Enclosing = statement_enclosing;
				return donode;

			case Tag.FOR:
				NodeStatementFor fornode = new NodeStatementFor();
				statement_enclosing = NodeStatement.Enclosing;
				NodeStatement.Enclosing = fornode;

					match_tag(Tag.FOR);
					match_tag('(');
					expression = boolean_or();
					match_tag(';');
					expression2 = boolean_or();
					match_tag(';');
					expression3 = boolean_or();
					match_tag(';');
					match_tag(')');
					statement1 = statement();
					fornode.init(expression, expression2, expression3, statement1);				

				NodeStatement.Enclosing = statement_enclosing;
				return fornode;

			case Tag.BREAK:
				match_tag(Tag.BREAK);
				match_tag(';');
				return new NodeStatementBreak();

			case '{':
				return block();

			default:
				return assign();
		}
	}

	private NodeStatement assign() throws IOException
	{
		NodeStatement statement;
		Token token = token_foreseen;

		match_tag(Tag.ID); // 1
			NodeExpressionId id = environment_top.get(token); // 2 Find corresponding ID in symbol tables
			if (id == null) 
				error (token.toString() + " undeclared");

			if (token_foreseen.tag == '=') // 3 Generate nodes for simple or array assigning
			{
				step();
				statement = new NodeStatementSet (id, boolean_or());
			}
			else
			{
				NodeExpressionOperatorAccess expression = offset(id);
				match('=');
				statement = new NodeStatementSetElement (id, boolean_or());
			}
		match_tag(';'); // 4

		return statement;
	}

	// represents operator hierarchy OR > AND > EQUALITY > RELATIONAL > ARITHMETIC +- > ARITHMETIC */ > UNARY > FACTOR
	private NodeExpression boolean_or() throws IOException
	{
		NodeExpression expression = boolean_and();
		while (token_foreseen.tag == Tag.OR)
		{
			Token token = token_foreseen;
			step();
			expression = new NodeExpressionLogicalOr(token, expression, boolean_and());
		}
		return expression;
	}

	private NodeExpression boolean_and() throws IOException
	{
		NodeExpression expression = equality();
		while (token_foreseen.tag == Tag.AND)
		{
			Token token = token_foreseen;
			step();
			expression = new NodeExpressionLogicalAnd(token, expression, equality());
		}
		return expression;
	}

	private NodeExpression equality() throws IOException
	{
		NodeExpression expression = relational();
		while (token_foreseen.tag == Tag.EQ || token_foreseen.tag == Tag.NE)
		{
			Token token = token_foreseen;
			step();
			expression = new NodeExpressionLogicalRelational (token, expression, relational());
		}
		return expression;
	}

	private NodeExpression relational() throws IOException
	{
		NodeExpression expression = expr();		
		switch (token_foreseen.tag)
		{
			case '<': case Tag.LE: case Tag.GE: case '>':
				Token token = token_foreseen;
				step();
				expression = new NodeExpressionLogicalRelational (token, expression, expr());
		}
		return expression;
	}

	private NodeExpression expr() throws IOException
	{
		NodeExpression expression = term();
		while (token_foreseen.tag == '+' || token_foreseen.tag == '-')
		{
			Token token = token_foreseen;
			step();
			expression = new NodeExpressionOperatorArithmetic (token, expression, term());
		}
		return expression;
	}

	private NodeExpression term() throws IOException
	{
		NodeExpression expression = unary();
		while (token_foreseen.tag == '*' || token_foreseen.tag == '/')
		{
			Token token = token_foreseen;
			step();
			expression = new NodeExpressionOperatorArithmetic (token, expression, unary());
		}
		return expression;
	}

	private NodeExpression unary() throws IOException
	{
		if (token_foreseen.tag == '-')
		{
			step();
			return new NodeExpressionOperatorUnary(TokenWord.minus, unary());
		}
		else if (token_foreseen.tag == '!')
		{
			Token token = token_foreseen;
			step();
			return new NodeExpressionLogicalNot (token, unary());
		}
		else
			return factor();
	}

	private NodeExpression factor() throws IOException
	{
		NodeExpression expression = null;
		switch (token_foreseen.tag)
		{
			case '(':
				step();
				expression = boolean_or();
				match_tag(')');
				return expression;

			case Tag.INTEGER:
				expression = new NodeExpressionConstant (token_foreseen, TokenWordType.Int);
				step();
				return expression;

			case Tag.REAL:
				expression = new NodeExpressionConstant (token_foreseen, TokenWordType.Float);
				step();
				return expression;

			case Tag.TRUE:
				expression = NodeExpressionConstant.True;
				step();
				return expression;

			case Tag.FALSE:
				expression = NodeExpressionConstant.False;
				step();
				return expression;

			case Tag.ID:
				String token_string = token_foreseen.toString();				
				NodeExpressionId id = environment_top.get(token_foreseen);
				if (id == null)
					error (token_foreseen.toString() + " undeclared");
				step();
				if (token_foreseen.tag != '[')
					return id;
				else
					return offset(id);

			default:
				error ("syntax error");
				return expression;
		}
	}

	// I := [E] | [E] I
	private NodeExpressionOperatorAccess offset (NodeExpressionId array) throws IOException
	{
		NodeExpression index;
		NodeExpression width;
		NodeExpression term1;
		NodeExpression term2;
		NodeExpression location;
		TokenWordType type = array.type;

		// 1-dimensional array: I := [E]
		match_tag('[');
		index = boolean_or();
		match_tag(']');
		type = ((TokenWordTypeArray)type).type; // get type of elements in the array
		width = new NodeExpressionConstant(type.width);
		term1 = new NodeExpressionOperatorArithmetic (new Token('*'), index, width);
		location = term1;

		// multi-dimensional array: I := [E] I
		while (token_foreseen.tag == '[')
		{
			match_tag('[');
			index = boolean_or();
			match_tag(']');
			type = ((TokenWordTypeArray)type).type;
			width = new NodeExpressionConstant(type.width);
			term1 = new NodeExpressionOperatorArithmetic (new Token('*'), index, width);
			term2 = new NodeExpressionOperatorArithmetic (new Token('+'), location, term1);
			location = term2;
		}	
		
		return new NodeExpressionOperatorAccess (array, location, type);
	}
	
	private void step() throws IOException
	{
		token_foreseen = lexer.scan();
	}

	private void error (String error_string)
	{
		throw new Error ("near line " + lexer.line + ": " + error_string);
	}

	private void match_tag (int tag) throws IOException
	{
		if (token_foreseen.tag = tag)
			step();
		else
			error ("syntax error");
	}
	
	private Lexer lexer;
	private Token token_foreseen;
	private Environment environment_top;
	private int memory_used; 	
	// PRIVATE BLOCK END
}