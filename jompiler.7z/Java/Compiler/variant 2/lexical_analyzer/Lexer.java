package lexical_analyzer;

import java.io.*;
import java.util.*;

import symbol_table.*;

public class Lexer
{
	public Lexer()
	{
		reserve (new TokenWord("if", Tag.IF));
		reserve (new TokenWord("else", Tag.ELSE));
		reserve (new TokenWord("do", Tag.DO));
		reserve (new TokenWord("while", Tag.WHILE));
		reserve (new TokenWord("break", Tag.BREAK));
		reserve (new TokenWord("for", Tag.FOR));
		reserve (TokenWord.True);
		reserve (TokenWord.False);
		reserve (TokenType.Int);
		reserve (TokenType.Float);
		reserve (TokenType.Bool);
		reserve (TokenType.Char);		
	}

	public Token scan() throws IOException
	{
		// ignore whitespaces
		for (;; readCharacter())
		{
			if (current_char == ' ' || current_char == '\t')
				continue;
			else if (current_char == '\n')
				++line;
			else
				break;
		}

		// scanning compound symbols
		switch (current_char)
		{
			case '/': // ignore comments
				readCharacter();				
				if (current_char == '/')
				{
					do
						readCharacter();
					while (current_char != '\n');
				}
				else if (current_char == '*')
				{
					do 
						readCharacter();
					while (Character.isLetterOrDigit(current_char));
					
					if (readCharacter('*') && readCharacter('/'))
						readCharacter();
					else
						// SYNTAX ERROR
				}		
				else
					return new Token('/');
				

			case '&':
				if (readCharacter('&'))
					return TokenWord.and;
				else
					return new Token('&');

			case '|':
				if (readCharacter('|'))
					return TokenWord.or;
				else
					return new Token('|');

			case '=':
				if (readCharacter('='))
					return TokenWord.eq;
				else
					return new Token('=');

			case '!':
				if (readCharacter('='))
					return TokenWord.ne;
				else
					return new Token('!');

			case '<':
				if (readCharacter('='))
					return TokenWord.le;
				else
					return new Token('<');
			
			case '>':
				if (readCharacter('='))
					return TokenWord.ge;
				else
					return new Token('>');
		}

		// scanning integers and floats
		if (Character.isDigit(current_char))
		{
			// gather all digits of integer value
			int int_value = 0;
			do
			{
				int_value = int_value*10 + Character.digit(current_char, 10);
				readCharacter();
			}
			while (Character.isDigit(current_char));

			if (current_char != '.') 
				return new TokenInteger(int_value);

			// gather all digits of real value
			float real_value = int_value;
			float divisor = 10;
			
			readCharacter();
			while (Character.isDigit(current_char))
			{
				real_value = real_value + Character.digit(current_char, 10) / divisor;
				divisor *= 10;
				readCharacter();
			}
			
			return new TokenReal(real_value);	
		}

		// scanning lexemes
		if (Character.isLetter(current_char))
		{
			StringBuffer buffer = new StringBuffer();
			do
			{
				buffer.append(current_char);
				readCharacter();
			}
			while (Character.isLetterOrDigit(current_char));
			String lexeme = buffer.toString();		

			TokenWord word = words.get(lexeme);
			if (word == null)
			{
				word = new TokenWord (lexeme, Tag.ID);
				words.put(lexeme, word);
			}

			return word;
		}

		// make token out of 1 symbol
		Token token = new Token (current_char);
		current_char = ' '; 
		return token;		
	}

	public static int line = 1;
	// PUBLIC BLOCK END

	private reserve (TokenWord word)
	{
		words.put(word.lexeme, word);
	}

	private readCharacter() throws IOException
	{
		current_char = (char) System.in.read();
	}

	boolean readCharacter(char char_to_match) throws IOException // for testing compound symbols like "&&" or "<="
	{
		readCharacter();
		if (current_char != char_to_match)
			return false;

		current_char = ' ';
		return true;
	}
	
	private current_char = ' ';
	private Hashtable words = new Hashtable();
	// PRIVATE BLOCK END
}