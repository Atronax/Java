package lexical_analyzer;

public class Token
{
	public Token (int tag_in)
	{
		tag = tag_in;
	}

	public String toString()
	{
		return "" + (char) tag;
	}
	
	public final int tag;
}