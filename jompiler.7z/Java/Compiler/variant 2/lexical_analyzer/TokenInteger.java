package lexical_analyzer;

public class TokenInteger extends Token
{
	public TokenInteger (int value_in)
	{
		super(Tag.INTEGER);
		value = value_in;
	}

	public String toString()
	{
		return "" + value;
	}

	public final int value;
}