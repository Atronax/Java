package lexical_analyzer;

public class TokenWord extends Token
{
	public TokenWord (String lexeme_in, int tag_in)
	{
		super(tag_in);
		lexeme = lexeme_in;
	}

	public String toString()
	{
		return lexeme;
	}

	public String lexeme = "";
	public static final TokenWord and = new TokenWord ("&&", Tag.AND); // collection of reserved words
	public static final TokenWord or = new TokenWord ("||", Tag.OR);
	public static final TokenWord eq = new TokenWord ("==", Tag.EQ);
	public static final TokenWord ne = new TokenWord ("!=", Tag.NE);
	public static final TokenWord le = new TokenWord ("<=", Tag.LE);
	public static final TokenWord ge = new TokenWord (">=", Tag.GE);	
	public static final TokenWord True = new TokenWord ("true", Tag.TRUE);
	public static final TokenWord False = new TokenWord ("false", Tag.FALSE);
	public static final TokenWord temp = new TokenWord ("t", Tag.TEMP);
	public static final TokenWord minus = new TokenWord ("minus", Tag.MINUS);	
}