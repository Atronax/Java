package lexical_analyzer;

public class Tag
{
	public final static int BASIC = 256; // basic types
	public final static int ID = 257;	// lexemes
	public final static int DO = 258; // conditional operators
	public final static int WHILE = 259;	
	public final static int IF = 260;
	public final static int ELSE = 261;
	public final static int BREAK = 262;
	public final static int AND = 263;
	public final static int OR = 264;
	public final static int FOR = 276;	
	public final static int INTEGER = 265; // number types
	public final static int REAL = 266;
	public final static int TRUE = 267; // booleans
	public final static int FALSE = 268;
	public final static int EQ = 269; // relational operators
	public final static int NE = 270;
	public final static int GE = 271;
	public final static int LE = 272;	
	public final static int INDEX = 273; // these are not lexical tokens, they are used to compose syntax tree, for intermediate code representation
	public final static int MINUS = 274;
	public final static int TEMP = 275;	
}