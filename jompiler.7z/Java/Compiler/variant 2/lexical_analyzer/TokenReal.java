package lexical_analyzer;

public class TokenReal extends Token
{
	public TokenReal (float value_in)
	{
		super (Tag.REAL);
		value = value_in;
	}

	public String toString()
	{
		return "" + value;
	}	

	public final float value;
}