package main;

import java.io.*;

import lexical_analyzer.*;
import syntax_analyzer.*;

public class Main
{
	public static void main (String[] args) throws IOException
	{
		Lexer lexer = new Lexer();
		Parser parser = new Parser(lexer);

		parser.program();		
		System.out.write('\n');
	}
}