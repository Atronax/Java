package lexer;

// token for all integer number lexemes
public class TokenNum extends Token
{
	public TokenNum (int value_in)
	{
		super (Constants.NUM);
		value = value_in;
	}

	public String ToString ()
	{
		return "" + value;
	}

	public final int value;
}