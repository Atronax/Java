package lexer;

// token for all real number lexemes
public class TokenReal extends Token
{
	public TokenReal (float value_in)
	{
		super (Constants.NUM);
		value = value_in;
	}

	public String ToString ()
	{
		return "" + value;
	}

	public final float value;
}