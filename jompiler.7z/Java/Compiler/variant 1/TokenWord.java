package lexer;

// saves tag in base class part and lexeme in subclass part
// used to create id tokens for lexemes and reserver words
public class TokenWord extends Token
{
	public TokenWord (int tag_in, String lexeme_in)
	{
		super (tag_in);
		lexeme = lexeme_in;
	}

	public String ToString ()
	{
		return lexeme;
	}

	public final String lexeme;
}