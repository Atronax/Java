package lexer;

// base class for all tokens
public class Token
{
	public Token (int tag_in)
	{
		tag = tag_in;
	}

	public String ToString ()
	{
		return "" + tag;
	}
	
	public final int tag;
}