package lexer;

import java.io.*;
import java.util.*;

public class Lexer
{
	public Lexer()
	{
		reserve (new TokenWord (Constants.TRUE, " true"));
		reserve (new TokenWord (Constants.FALSE, "false"));
		reserve (new TokenWord (Constants.LESS, "<"));
		reserve (new TokenWord (Constants.LESS_EQUAL, "<="));
		reserve (new TokenWord (Constants.EQUAL, "=="));
		reserve (new TokenWord (Constants.NOT_EQUAL, "!="));
		reserve (new TokenWord (Constants.GREATER_EQUAL, ">="));
		reserve (new TokenWord (Constants.GREATER, ">"));
	}

	public Token scan() throws IOException
	{
		// ignore whitespaces
		for (;;current_char = (char) System.in.read())
		{
			if (current_char == ' ' || current_char == '\t')
				continue;
			else if (current_char == '\n')
				++line;
			else
				break;
		}

		switch (current_char)
		{
			// ignore commentaries starting with "//" or "/* */"
			case '/':		
				current_char = System.in.read();				
				if (current_char == '/') // case of "//" comments
				{
					do											
						current_char = System.in.read();
					while (current_char != \n);

					current_char = System.in.read();					
				}
				else if (current_char == '*') // case of "/* */" comments
				{
					do						
						current_char = (char) System.in.read();
					while (Character.isLetterOrDigit (current_char));					
					
					if (matches(System.in.read(), '*') && matches(System.in.read(), '/'))
						current_char = System.in.read();
				}	
				break;

			// make tokens out of relational operator lexemes
			case '<':				
				current_char = System.in.read();
				if (current_char == '=')
					return words.get('<=');
				else
					return new TokenWord('<');				
				break;

			case '=':
				current_char = System.in.read();
				if (current_char == '=')
					return words.get('==');
				else
					return new TokenWord('=');				
				break;

			case '>':
				current_char = System.in.read();
				if (current_char == '=')
					return words.get('>=');
				else
					return new TokenWord('>');				
				break;

			case '!':
				current_char = System.in.read();
				if (current_char == '=')
					return words.get('!=');
				else
					return new TokenWord('!');				
				break;
		}

		// gather digits into number and return corresponding token
		if  (Character.isDigit(current_char))
		{
			// gather digits into integer
			int int_value = 0;
			do
			{
				int_value = int_value*10 + Character.digit(current_char, 10);
				current_char = (char) System.in.read();
			}
			while (Character.isDigit(current_char));

			if (current_char != '.')
				return new TokenNum(int_value);
			
			// if there is '.' we have float number, so:
			float float_value = int_value;

			int divisor = 10;
			current_char = (char) System.in.read();
			while (Character.isDigit(current_char))
			{				
				float_value = float_value + Character.digit(current_char, 10) / divisor;
				divisor *= 10;
			}
			
			return new TokenReal(float_value);

		}
	
		// gather symbols into buffer, make string of them
		// check words table: return corresponding token, if it is there, or make new one and store it there
		if (Character.isLetter(current_char))
		{
			StringBuffer buffer = new StringBuffer();
			do
			{
				buffer.append(current_char);
				current_char = (char) System.in.read();
			}
			while (Character.isLetterOrDigit (current_char));

			String lexeme = buffer.toString();
			TokenWord word = words.get(lexeme);
			if (word == null)
			{
				word = new TokenWord (Constant.ID, lexeme);
				words.put(word);
			}

			return word;
		}

		// the symbol is a token itself
		Token token = new Token (current_char);
		current_char = ' ';
		return token;
	}

	public int line = 1;

	private void reserve (TokenWord token)
	{
		words.put (token.lexeme, token);
	}

	private bool matches throws SyntaxErrorException (char symbol_in, char symbol_to_match)
	{
		if (symbol_in == symbol_to_match)
			return true;
		else
		{
			throw SyntaxErrorException ("Symbol " + symbol_to_match + " has not been found at " + __LINE__);
			return false;
		}
	}

	private char current_char = ' ';
	private Hashtable words = new Hashtable();
}